# XML Schema Documents for CTC Phase 6

The XSDs and Zip files in this directory are schema definitions for messages sent to and from the CTC Traders system. They are intended to allow developers to write schema valid messages, however please be aware that there are also business rules that will be applied, and that messages that conform to these schema are not guaranteed to be accepted by the system. 

The following resources will be helpful in understanding how to use these XSDs further:

* [NCTS Technical Interface Specification](https://developer.service.hmrc.gov.uk/guides/ctc-traders-tis/)
* [CTC Traders API service guide](https://developer.service.hmrc.gov.uk/guides/ctc-traders-service-guide)
* 

The XSDs are also contained in the ALL_CTC_XSDs_v60.4.16.zip file.

## XSD versions

The XSDs in this directory are version 60.4.16.
